// Tasks page. Opens on My queue (every open item, split by whose move it is);
// "My tasks" shows one card per task (T1–T23), grouped by the 4 areas, each tagged with its responsibility.
// Every task opens the same task screen: record, form, checks, progress, conversation.

import { useApp } from '../../store/appStore';
import { AREAS } from '../../store/areas';
import { queueCounts } from '../../store/queue';
import { taskBadges } from '../../store/selectors';
import { ActionCard, PageHeader, SegmentedControl } from '../../ui';
import { RESPONSIBILITIES, TASKS } from '../manifest';
import { MyQueue } from '../queue/MyQueue';
import { RulesOnTask } from '../rules/RulesOnTask';
import { TaskScreen } from '../task/TaskScreen';

export function TasksTab() {
  const s = useApp();
  const screen = s.nav.tasks.screen;
  if (screen) return <TaskScreen key={screen} code={screen} />;
  const badges = taskBadges(s);
  const counts = queueCounts(s);
  const view = s.queueUi.view;
  return (
    <>
      <PageHeader
        title="Tasks"
        subtitle={
          view === 'queue'
            ? 'Everything open, in one list: what needs you, what waits on a checker, and what is coming up.'
            : 'Your 23 tasks in the 4 areas you work in. The tag shows what each one keeps right; the badge, what waits for you.'
        }
        actions={
          <SegmentedControl<'queue' | 'tasks'>
            label="View"
            value={view}
            onChange={(v) => s.setQueueUi({ view: v })}
            options={[
              { value: 'queue', label: `My queue${counts.me ? ` (${counts.me})` : ''}` },
              { value: 'tasks', label: 'My tasks T1–T23' },
            ]}
          />
        }
      />
      {view === 'queue' ? (
        <MyQueue />
      ) : (
        <>
          <p className="resp-legend">
            {RESPONSIBILITIES.map((r) => (
              <span key={r.id}>
                <span className="code-tag">{r.id}</span> {r.title}
              </span>
            ))}
          </p>
          {AREAS.map((a) => (
            <section key={a.id} className="resp-group">
              <h2 className="resp-group__title">
                <span className="code-tag">{a.ref}</span> {a.title}
              </h2>
              <p className="resp-group__why">{a.what}</p>
              <div className="card-grid">
                {TASKS.filter((t) => t.area === a.id).map((t) => (
                  <div key={t.code} className="task-card">
                    <ActionCard
                      icon={t.icon}
                      accent={t.accent}
                      title={t.title}
                      description={t.description}
                      code={`${t.code} · ${t.responsibility}`}
                      cadence={`${t.cadence} · ${t.type}`}
                      badge={badges[t.code]}
                      onClick={() => s.navigate({ tab: 'tasks', screen: t.code, id: null })}
                    />
                    <RulesOnTask task={t.code} />
                  </div>
                ))}
              </div>
            </section>
          ))}
        </>
      )}
    </>
  );
}
