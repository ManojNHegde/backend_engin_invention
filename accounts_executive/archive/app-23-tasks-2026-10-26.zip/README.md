# Accounts Executive app (mockup)

Desktop position app for the **Accounts Executive (R01)**, scoped to §11.1–11.4 (revised 26-Oct-2026 to the shared engine docs of Oct 1, 2026) of the reference roles (Purchase, Inventory, Sales, AR/AP). Same UI as the Credit Controller app; the role, its responsibilities and its tasks are new. Mock data from the shared biscuit-plant scenario.

- Tasks and responsibilities: `../01_accounts_executive_tasks_and_responsibilities.md`
- Designed UI per task: `../02_accounts_executive_designed_ui.md`

## Run

```bash
npm install      # node_modules is a link to credit-controller-app/node_modules for now; install for your own copy
npm run dev      # opens http://localhost:5174
npm run typecheck
npm test         # answer keys + the whole scenario + a render of every screen
npm run build
```

## Use

- **5 areas:** Dashboard · Tasks · Reports · Rules · CnC.
- **Tasks** opens on **My queue** (Needs me · Waiting on others · Coming up, filtered by area). **My tasks** shows the 23 tasks grouped by the 4 areas, each tagged R1, R2 or R3.
- **One task screen for all 23 tasks:** the record (what arrived, what the system worked out, with its source), the run and its lines (for month-end runs), **what you fill in**, the **checks** (Stop · Reason · Warn), progress through the checkers, and the conversation.
- **Match variances are not Teja's.** Ravi (Procurement Officer) and Kiran (Contracts & Services) raise them; the voucher or bill waits in **With others** until Rajan approves the variance, then Teja posts it (doc 01 §0).
- **Checkers are stubs.** Rajan (Accounts Manager), Usha (Finance Controller), Venkat (Compliance Officer) and Farid (Credit Controller) answer from the Scenario panel → "Checkers", including the variance approvals. This stands in for the one approval mechanism to be designed with the Accounts Manager's owner.
- **Scenario launcher** (bottom-left): 42 steps, 05-Oct to 31-Oct. Plays other roles, shows "Your turn", jumps to any step, refusal tests, company rules editor (tolerances, OCR flag, TDS threshold, Perpetual/Periodic).

## Structure

```
src/
  domain/              accounting.ts (match, TDS, MSME due date …, tested) · tasks.ts (each task's record, form, checks, checkers) · myRules.ts
  store/               app state: Teja's actions + mocked actions of other roles; queue, CnC, suggestions
  accounts-executive/  manifest (R1–R3, T1–T23, reports), 5 tabs, the task screen, dashboard tiles, reports, rules
  mock/                seed data, the scenario timeline, the simulator panel, the end-to-end test
  ui/ shell/ styles/   copied unchanged from the Credit Controller app
```

Items with no step in the shared scenario (T5, T6, T9–T11, T14–T23) use illustrative figures, marked in `mock/seed.ts` and `mock/scenario.ts`.
